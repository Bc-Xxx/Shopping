create function col_description(oid, integer) returns text
    stable
    strict
    parallel safe
    language sql
BEGIN ATOMIC
 SELECT pg_description.description
    FROM pg_description
   WHERE ((pg_description.objoid = $1) AND (pg_description.classoid = ('pg_class'::regclass)::oid) AND (pg_description.objsubid = $2));
END;

comment on function col_description(oid, integer) is 'get description for table column';

alter function col_description(oid, integer) owner to postgres;

